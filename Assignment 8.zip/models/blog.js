const mongoose = require('mongoose');
const Review = require('./review');


const blogSchema = new mongoose.Schema({

    title: {
        type: String,
        require: true,
        unique: true
    },
    img: {
        type: String,
        require: true,
        unique: true
    },
    desc: {
        type: String,
        require: true
    },
    author: {
        type: String,
        require: true
    },
    reviews: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Review'
    }]
})

const Blog = new mongoose.model('Blog',blogSchema);

module.exports = Blog;