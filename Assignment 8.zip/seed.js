const mongoose = require('mongoose');
const Blog = require('./models/blog');

const blogs = [
        {
        title : 'Kempty Fall',
        img : "https://images.unsplash.com/photo-1619717823034-0f5878db088c?ixid=MnwxMjA3fDB8MHx0b3BpYy1mZWVkfDR8RnpvM3p1T0hONnd8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        desc : "Gigantic Fall with somersault of the streams before hitting the bottom, Kempty Falls is the most popular and one of the oldest tourist spot near Mussoorie. Developed before more than 150 years ago by a British man, Kempty Falls is the most fascinating picnic spot or a perfect day out place nearby Mussoorie at a distance of 15 km.",
        author : "Vishal Bharti"
    }, 
    {
        title : 'Bangkok, Thailand',
        img : "https://images.unsplash.com/photo-1545153976-5d451256a9a1?ixid=MnwxMjA3fDB8MHx0b3BpYy1mZWVkfDJ8RnpvM3p1T0hONnd8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        desc : "Bangkok, Thailand’s capital, is a large city known for ornate shrines and vibrant street life. The boat-filled Chao Phraya River feeds its network of canals, flowing past the Rattanakosin royal district, home to opulent Grand Palace and its sacred Wat Phra Kaew Temple. Nearby is Wat Pho Temple with an enormous reclining Buddha and, on the opposite shore, Wat Arun Temple with its steep steps and Khmer-style spire",
        author : "Kartik Bhaiya"
    },
    {
        title : 'Oak Alley Plantation, Vacherie, United States',
        img : "https://images.unsplash.com/photo-1528108827304-51446e007137?ixid=MnwxMjA3fDB8MHx0b3BpYy1mZWVkfDExfEZ6bzN6dU9ITjZ3fHxlbnwwfHx8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        desc : "Oak Alley Plantation is a historic plantation located on the west bank of the Mississippi River, in the community of Vacherie, St. James Parish, Louisiana, U.S. Oak Alley is named for its distinguishing visual feature, an alley (French allée) or canopied path, created by a double row of southern live oak trees about 800 feet (240 meters) long, planted in the early 18th century — long before the present house was built. The allée or tree avenue runs between the home and the River. The property was designated a National Historic Landmark for its architecture and landscaping, and for the agricultural innovation of grafting pecan trees, performed there in 1846–47 by an enslaved gardener.",
        author : "Munna Bhaiya"
    },
    {
        title : 'Hot Air Balloon in Cappadocia, Turkey',
        img : "https://images.unsplash.com/photo-1604156789095-3348604c0f43?ixid=MnwxMjA3fDB8MHx0b3BpYy1mZWVkfDE2fEZ6bzN6dU9ITjZ3fHxlbnwwfHx8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        desc : "Cappadocia in central Turkey is perhaps most well-known for the panoramic view of hundreds of hot air balloons ebbing and flowing above valleys and volcanic “fairy chimney” formations. Though it is but one of the many things to do in Cappadocia, hot air ballooning is one of the most popular activities in the region for a number of reasons. Hot air ballooning in Cappadocia is incredible not only because of the unique and rugged landscape, but also because the balloons fly approximately 250 days of the year, compared to about 60 days elsewhere in Europe. Not only can you soar above the terrain in summer and spring, you can explore the winter wonderland from above.",
        author : "Sabeel Bhaiya"
    },
    {
        title : 'Hong Kong',
        img : "https://images.unsplash.com/photo-1590765283894-6e7ae619120b?ixid=MnwxMjA3fDB8MHx0b3BpYy1mZWVkfDQyfEZ6bzN6dU9ITjZ3fHxlbnwwfHx8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
        desc : "Hong Kong became a colony of the British Empire after the Qing Empire ceded Hong Kong Island at the end of the First Opium War in 1842.[16] The colony expanded to the Kowloon Peninsula in 1860 after the Second Opium War and was further extended when Britain obtained a 99-year lease of the New Territories in 1898.[17][18] The whole territory was transferred to China in 1997.[19] As a special administrative region, Hong Kong maintains separate governing and economic systems from that of mainland China under the principle of . Originally a sparsely populated area of farming and fishing villages,[16] the territory has become one of the world's most significant financial centres and commercial ports.",
        author : "Anuj Bhaiya"
    }

]

const seedDB = async()=>{
 
    await Blog.insertMany(blogs).then(()=>{
        console.log('DB seeded');
    }).catch((err)=>{
        console.log('error in seeding');
        console.log(err);
    });
}

module.exports = seedDB;